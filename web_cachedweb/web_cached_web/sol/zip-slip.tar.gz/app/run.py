import os

os.system("ping -c 1 172.17.0.1")
